// Copyright (c) Microsoft Corporation. All rights reserved.
// SPDX-License-Identifier: MIT
//wifi
#define IOT_CONFIG_WIFI_SSID "Fluxgen"
#define IOT_CONFIG_WIFI_PASSWORD "wifirocks"

// Azure IoT
#define IOT_CONFIG_IOTHUB_FQDN "fluxgen-testhub.azure-devices.net"
#define IOT_CONFIG_DEVICE_ID "testesp"
#define IOT_CONFIG_DEVICE_KEY "KXxkBoHnE7uezmijN+8QTM2N/fmVyG0B9AIoTLTmUVk="

// Publish 1 message every 5 minutes
#define TELEMETRY_FREQUENCY_MILLISECS 60000
/*
{
    "type": "ota_update",
    "version": "1.0.1",
    "url": "https://your-storage-account.blob.core.windows.net/firmware/firmware.bin"
}
*/
